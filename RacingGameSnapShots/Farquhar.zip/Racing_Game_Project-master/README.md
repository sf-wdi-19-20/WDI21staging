##OOP Racing Game


### Technologies Used
*In this racing game all the code is OOP structured. The game is designed using HTML, JavaScript, & CSS.*

###Existing features
*In this two player racing game player one hits space bar and player two hits the enter key to move your player through space. Once you get to the end the running time will go away and your finishing time will be posted.*

###Planned features
*In the future I would like the cat to blowup at the end of the game, the times to remain posted through the next game and to have planets that you need to avoid with other key presses.*
