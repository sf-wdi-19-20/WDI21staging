# Coin-Racer
A race against a foe to gather a certain number of coins to impress the princess. Beware of what gets in your way!

Hello instructor or TA!

Starting to get a hang of using jQuery and OOP. OOP really cleans up strangling unecessary variables.
Css and html still needs to be heavily improved on in terms of classes overall format. Maybe also learn 
how to use canvas.

Game FEATURES and INSTRUCTIONS
Game starts with players putting in their name. Then the players click on the characters they want.
Then when both players are ready they lock in their characters with the button. After users are comfortable with their
controls. They hit play.
Be the first to make it to the princess first without getting hit by enemies.

FEATURES to be ADDED
It's called Coin-Racer but I still need to ADD COINS for the players to collect and bring to the princess. Then,
make a 'scoredboard' to keep track of the coins collected and lost. Also, make the background of the player 'tracks'
say 'practice your controls, then when ready hit  PLAY'
