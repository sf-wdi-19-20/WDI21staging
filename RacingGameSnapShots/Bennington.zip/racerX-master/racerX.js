var carPosition;

$(document).ready(function() {
	
	// $("#racer").click(function(event) {
	// 	backgroundColor = '#'+Math.floor(Math.random()*16777215).toString(16);
	// 	$(event).css(backgroundColor)
	// }
	



	$(document).keypress(function(event) {
	  //executes on keypress
	    if (event.keyCode === 97) { 
	    //moves racecar 1 on "a"
	    	carPosition = $("#racer").css("left");
	    	if (parseInt(carPosition)< 600) {
	    	//sets finish to 550px
	    	 newPosition = (parseInt(carPosition) + 50);
	    	//sets new position to last position + 50 px
	    	$("#racer").css("left", newPosition + "px");
	    	}
	    	else alert("Player 1 wins!")
	    };
	 });    

	$(document).keypress(function(event) {
	    //executes on keypress
	    if (event.keyCode === 108) { 
	    	//moves racecar2 on "l"
	    	carPosition = $("#racer2").css("left");
	    	if (parseInt(carPosition)< 600) {
	    	//finish line at 550 px
	    	var newPosition = (parseInt(carPosition) + 50);
	    	//sets new position to last position + 50 px
	    	$("#racer2").css("left", newPosition + "px");
	    	}
	    	else alert("Player 2 wins!")
	    };
	 });    

});
  $('#reset').click(function() {
    location.reload();
  });

  // $("#button").click(function() {
  //   $('#3').fadeOut(1000, function(){
  //     $('#2').fadeOut(2000, function(){
  //       $('#1').fadeOut(3000);
  //     });
  //   });
  // });
