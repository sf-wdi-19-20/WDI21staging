##OOP Racing Game
### WDI Weekend Project

###Workflow & Submission

* for my ref: Use either HTML or, even better, [markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) to format this file as you document your project.



### Technologies Used
*What technologies did you use while developing this project?*
Started by listing my classes and objects to be used. In javascript, I formed the player function and 2 player instances to feed it. I used my old css and changed the picture. I updated my HTML to include jquery and deleted the second track. I was unable to get the track constructor to work

###Existing features
*What features does your new racing app have?*
Players use either a or l keys to reach the end of the track. 
start button clears board

###Planned features
*What changes would you make to your project if you continued with it in the future?*
Most important  - infinite tracks possible with track constructor
color or icon options for each player
Only 1 letter would win and an alert would announce winner.
Sexier layout.
