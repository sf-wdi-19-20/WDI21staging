console.log("Sanity Check: JavaScript is working!");

//////////////////////
/* Global variables */
// var keysPressed = {};


/////////////////////
/* Event listeners */
$(document).keydown(function (key) {
  game.keysPressed[key.keyCode] = true;
});
$(document).keyup(function (key) {
  delete game.keysPressed[key.keyCode];
});



//////////////////////////////////////////////////
/* Functions */

/* Decides the direction the road will turn, could be moved to Track constructor */
function generateTrack() {
  var randomDir = Math.random();
  var change = 0;
  if (raceTrack.curveDirection !== "straight") { // for gameplay, initialization in the else statement
    if (randomDir < .8) { // keep turning
      raceTrack.curveDirection === "left" ? change = -1 : change = 1; 
    } else if (randomDir < .9) { // go straight
      change = 0; 
    } else { // go oposite direction
      raceTrack.curveDirection === "left" ? change = 1 : change = -1;
    } 
  } else { // for initialization of map when road should be more straight
      if (randomDir < .6) { // go straight
      change = 0; 
    } else if (randomDir < .8) { // go left
      change = -1; 
    } else { // go right
      change = 1;
    }
  }
  change = change * (parseInt(randomDir * 100) % 3 === 0 ? 1 : 2 );
  return change;
}

/////////////////////////
/* Object constructors */
function Game() {
  this.running = false;
  this.someoneCrashed = false;
  this.keysPressed = {};
  this.gameSpeed;
  this.startTrack;
}

// Game.prototype.init
Game.prototype.init = function() {
  bluePlayer = new Player("blueCar", "Blue Driver");
  redPlayer = new Player("redCar", "Red Driver");
  $(".cars").css("opacity", 0);
  this.gameSpeed = 5;
  this.keysPressed = {};
};

Game.prototype.initMap = function() {
  this.startTrack = "";
  this.keysPressed = {};
  raceTrack.leftWidth = raceTrack.trackWidth / 4;
  raceTrack.roadWidth = raceTrack.trackWidth / 2;
  raceTrack.rightWidth = raceTrack.trackWidth / 4;
  bluePlayer.leftPx = 187;
  redPlayer.leftPx = 187;
  raceTrack.curveDirection = "straight";
  for (var i = 0; i < 300; i++) {
    raceTrack.changeWidth(generateTrack());
    raceTrack.roadHitBoxUpdate();
    this.startTrack = trackTemplate(raceTrack) + this.startTrack;
  }
  $(".race-tracks").css("opacity", "0");
  $(".race-tracks").html(this.startTrack);
  $(".race-tracks").animate({
    opacity: 1
  }, 1500);
  $(".cars").css("bottom", 0);
  $(".cars").animate({
    opacity: 1,
    bottom: "30px"
  }, 1500);

  $("#blue-car").css ("left", bluePlayer.leftPx + "px" );
  $("#red-car").css ("left", redPlayer.leftPx + "px" );
}

/* Start Game */
Game.prototype.start = function() {
  keysPressed = {};
  raceTrack.curveDirection = "left";
  this.running = true;
  var driveInterval = setInterval(function() {
    if (game.running) {
      bluePlayer.move();
      redPlayer.move();
      raceTrack.leftOrRight();
      raceTrack.changeWidth(generateTrack());
      raceTrack.render();
      raceTrack.roadHitBoxUpdate();
      if (raceTrack.hasCrashed(bluePlayer)) {
        redPlayer.score++;
        $("#points-red").text(redPlayer.score);
      } else if (raceTrack.hasCrashed(redPlayer)) {
        bluePlayer.score++;
        $("#points-blue").text(bluePlayer.score);
      }    
    } else { 
      clearInterval(driveInterval);
    }
  }, this.gameSpeed);

};

// A starter Player constructor.
function Player(car, name) {
  this.name = name || "Blue Driver";
  this.score = 0;
  this.leftPx = 187;
  this.carAngle = "straight"; //  value will change to leftTurn and rightTurn
  this.team = car || "blueCar";
  this.keyMap = (this.team === "blueCar") ? {"a" : 65, "d" : 68} : {"j" : 74, "l" : 76};
  this.carID = (this.team === "blueCar") ? "#blue-car" : "#red-car";
};
Player.prototype.move = function() {
  if ((game.keysPressed[this.keyMap.a] && !game.keysPressed[this.keyMap.d]) 
    || (game.keysPressed[this.keyMap.j] && !game.keysPressed[this.keyMap.l])) {
      // if (this.carAngle === "leftTurn") {}// add soft turning, not straight from right to left
      this.carAngle = "leftTurn";
      this.leftPx--;
      $(this.carID).css ("left", this.leftPx + "px");
  } else if ((!game.keysPressed[this.keyMap.a] && game.keysPressed[this.keyMap.d]) 
    || (!game.keysPressed[this.keyMap.j] && game.keysPressed[this.keyMap.l])) {
      this.carAngle = "rightTurn";
      this.leftPx++;
      $(this.carID).css ("left", this.leftPx + "px" );
  } else {
    this.carAngle = "straight";
  }
  this.leftWidth = $(this.carID).css ("left");
};


// Track constructor.
function Track() {
  this.trackWidth = 400;
  this.leftWidth = this.trackWidth / 4;
  this.roadWidth = this.trackWidth / 2;
  this.rightWidth = this.trackWidth / 4;
  this.leftWidthPx = this.leftWidth + "px";
  this.roadWidthPx = this.roadWidth + "px";
  this.rightWidthPx = this.rightWidth + "px";
  this.curveDirection = "straight";
  this.roadHitBox = [];
  this.carRightOffset = 24;
  this.carLeftOffset = 0;
};
Track.prototype.changeWidth = function(leftChange, roadChange) {
  if (leftChange < 0 && this.leftWidth < 20) {
    this.curveDirection = "right";
  } else if (leftChange > 0 && this.rightWidth < 20) {
    this.curveDirection = "left";
  } else
  this.leftWidth += leftChange || 0;
  this.roadWidth += roadChange || 0;
  this.rightWidth = this.trackWidth - this.leftWidth - this.roadWidth;
  this.leftWidthPx = this.leftWidth + "px";
  this.roadWidthPx = this.roadWidth + "px";
  this.rightWidthPx = this.rightWidth + "px";
};
Track.prototype.render = function() { // prepends new track line and removes the bottom one
  var trackHtml = trackTemplate(this);
  $(".race-tracks").prepend(trackHtml);
  $("#blue-race-track .track-lines:last").remove();
  $("#red-race-track .track-lines:last").remove();
};
Track.prototype.leftOrRight = function() {
  var randomVar =  Math.random();
  if (randomVar < .05 && this.roadWidth > 90) { // narrow the road 1px
    this.changeWidth(0, -1); 
  } else if (randomVar > .99) { // change direction
    this.curveDirection = ((this.curveDirection === "left") ? "right" : "left"); 
  }
};
Track.prototype.roadHitBoxUpdate = function() {
  this.roadHitBox.unshift([this.leftWidth, this.trackWidth - this.rightWidth])
  if (game.running) {
    this.roadHitBox.pop();
  }
};
Track.prototype.hasCrashed = function(player) {
  // top left corner of cars compares to roadHitBox index 254 first value
  // top right corner same index and second value
  // bottom left corner of cars compares to roadHitBox index 282 and first value
  // bottom right corner same index and second value
  if ((player.leftPx + this.carLeftOffset < this.roadHitBox[254][0]) || 
    (player.leftPx + this.carLeftOffset < this.roadHitBox[282][0]) || 
    ((player.leftPx + this.carRightOffset) > this.roadHitBox[254][1]) || 
    ((player.leftPx + this.carRightOffset) > this.roadHitBox[282][1])) {
    game.running = false;
    game.someoneCrashed = true;
    $("#start-button").text("New Game");
    return true;
  } else {
    return false;
  }
}

////////////////////
/* Document.ready */
$(function() { /* Document.ready */
  console.log("Sanity Check: Document ready!");
  $("#buttons").click(function (e) {
    if (e.target.id === "start-button") {
      if ($("#start-button").text() === "New Game") {
        game.running = false;
        someoneCrashed = false;
        game.initMap();
        $("#start-button").text("Start Game");
      } else if ($("#start-button").text() === "Start Game") {
        $("#start-button").text("Double Speed");
        game.start();
      } else if ($("#start-button").text() === "Double Speed") {
        game.start();
      }
    } else if (e.target.id === "reset-button") {
      game.running = false;
      game.someoneCrashed = false;
      game.init();
      game.initMap();
      // bluePlayer.score = 0;
      $("#points-blue").text(bluePlayer.score);
      // redPlayer.score = 0;
      $("#points-red").text(redPlayer.score);
      $("#start-button").text("Start Game");

    }
  });
  
  // $("h2").click(function (e) {
  //   if (e.target.id === "blueName") {

  //   } else if (e.target.id === "redName") {
      
  //   }
  // })




  /* load template for one line of track, nees values rightWidth, roadWidth and leftWidth */
  trackTemplate =  _.template($('#track-template').html());

  /* Start the game! */
  game = new Game();
  raceTrack = new Track();
  game.init();

}); /* Document.ready end */