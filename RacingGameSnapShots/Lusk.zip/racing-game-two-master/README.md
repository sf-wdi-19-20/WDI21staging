# racing-game-two
Racing game, incorporating what I have learned about objects
Game has trouble recognizing keypresses, doesn't move like it is supposed to.
