console.log("wOrKiNg");
$(document).ready(function(){
    var car1 = 0;
    var car2 = 0;

    function Game() {
        this.player1 = player1;
        this.player2 = player2;
    }

    function Game (player1, player2, track) {
      this.player1 = player1;
      this.player2 = player2;
      this.track = track;
    }

    // `Game.prototype.init` kicks off a new game with a board and two players
    Game.prototype.init = function() {
      //
    };

    function Player(playerName, position) {
      this.playerName = playerName;
      this.position = position;
    };

    var player1 = new Player("Player 1", $('#player1-start'));
    var player2 = new Player("Player 2", $('#player2-start'));


    Player.constructor.prototype.move = function() {

      $(window).keypress(function(event) {  
            
      var keyCode = (event.keyCode ? event.keyCode : event.which); 
       
          if ((event.which === 65 || event.keyCode === 65) && car1 < 8) {
            var $player1 = $("table tr td#player1-start").remove();
            var $nextBlock = $(".block").eq(car++);
            $nextBlock.append(player1);
        }
        if ((event.which == 76 || event.keyCode == 76) && car2 < 8) {
            var $player2 = $("table tr td#player2-start").remove();
            var $nextBlock = $(".block").eq(car2++);
          $nextBlock.append(player2);
        }
        })
    };

    Player.constructor.prototype.winner = {
    
    if (car1 > 7) {
    alert(player1.name + " wins!");

    } else if (car2 > 7){
    alert(player2.name + " wins!");
    }
    else if (car1 && car2 > 7){
    alert("Both players win!");
    }
    };
    }

    var game = new Game();
    game.init();
});
