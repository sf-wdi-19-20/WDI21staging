##OOP Racing Game

** How to play **

Load - intro.html -, read the instuctions and hit play.

Enter player one name and pick a color, hit enter.
Enter plyer two name and pick a color, hit enter.

click play

Race!!

Play again to keep current score, reset to start again at intro.


### Technologies Used
*What technologies did you use while developing this project?*

Jquery

Underscore



###Existing features
*What features does your new racing app have?*

Introduction page

Updating score count

Custom name and token color



###Planned features
*What changes would you make to your project if you continued with it in the future?*

A count down timer to start the race

*****Questions

As far as using Object Orientation, I tried a few different methods, and wasn't able to get the board or game initiation to work with an object constructor. It was lost on me.

The other thing I struggled with was .toggle() to move the characters. It was suggeste that I try that but got it to work not at all, ended up going with a different method all together.
