// OOP Racing Game example boilerplate code


function Game(player1, player2, track){
  this.player1 = new Player(1);
  this.player2 = new Player(2);
  this.track = track;

  this.winner = null;
}



// `Game.prototype.init` kicks off a new game with a board and two players
Game.prototype.init = function() {
  // this points to game
  var _this = this;
  $(document).on('keypress', function(event){
    // this points to #document
    // i.e it points to whatever triggered the event
    if(event.which ===  122)
      _this.player1.move(1);
      // if player1.moveCount > whatever
        //_this.winner = player1
       else if(event.which === 109)
        _this.player2.move(2);
   // else if 65
     // move player 2
  });
};

// A starter Player constructor.
function Player(playerName) {
  this.playerName = playerName ;
  this.moveCount = 0;

};

// Remember: prototypes are shared functions between all game instances
Player.prototype.move = function(me) {
   $('#p' + me).animate({'margin-left': '+=30px'}, "fast");
   this.moveCount += 1;
};

// A starter Track constructor.
function Track() {
  //Tracks the cells of the board instance
  //this.$cells = ...

  //Store any other properties that board may have below, such as a reset option
};

// Start the game!
$(document).ready(function () {
  var game = new Game();
  game.init();
});
