# Let's race!
WDI / Racing Game

Two players test their button mashing skills with the speed of Sonic and Knuckles:
  - Add name
  - Click start to begin race
  - For Sonic (player 1 / blue) press 'a'
  - For Knuckles (player 2 / red) press 'l'
  - First player to cross the finish line wins!
