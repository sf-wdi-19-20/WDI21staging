##OOP Racing Game
### WDI Weekend Project


### Game Instructions:
Player 1 = A Key
Player 2 = L Key


### Technologies Used
* HTML, JavaScript and CSS
* HTML - Game area created using Tables
* JavaScript - Game flow and behaviour using Event Listeners and JQuery .attr() to manipulate the movement of characters
* CSS - primarily trying to place DIVS to contain the various elements of the game - title, scoreboard, racetrack


### Existing features
* Basic game functionality and score tracking


### Planned features
* After speaking with classmates, I have a better idea now as to how to use player customization - name & character (not sure if this falls under the OOP policy, however think I can make the functionality work using Java Script)
